<?php
//Current semester

$c_s= 91;


//Required to submit the Previous semestes  books
$r_s= 1  ;

?>
            