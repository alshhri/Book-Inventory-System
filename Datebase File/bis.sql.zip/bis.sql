-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- المزود: localhost
-- أنشئ في: 24 أبريل 2010 الساعة 11:28
-- إصدارة المزود: 5.0.51
--  PHP إصدارة: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- قاعدة البيانات: `bis`
--

-- --------------------------------------------------------

--
-- بنية الجدول `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `ISBN` varchar(200) NOT NULL,
  `title` varchar(200) default NULL,
  `edition` varchar(200) default NULL,
  `price` varchar(200) default NULL,
  `m_quantity` varchar(100) default '0',
  `f_quantity` varchar(100) default '0',
  PRIMARY KEY  (`ISBN`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- إرجاع أو إستيراد بيانات الجدول `books`
--

INSERT INTO `books` (`ISBN`, `title`, `edition`, `price`, `m_quantity`, `f_quantity`) VALUES
('0-201-75570-X', 'NorthStar Listening and Speaking', '2', '$ 97', '6', '4'),
('0-201-75571-8', 'NorthStar Reading and Writing', '2', '$ 78', '8', '3'),
('0-201-75573-4', 'NorthStar Reading and Writing', '2', '$ 100', '10', '34'),
('0-521-54496-3', 'Writer''s at Work: The Dhort Composition', '2005', '$ 101', '21', '4'),
('987-007-1488488', 'Schaum''s Quick Guide to Writing Great Research Papers', '2', '$ 81', '3', '43'),
('987-007-3229720', 'Discrete Mathematics and its Applications', '6', '$ 53', '5', '3'),
('987-013-0457875', 'Elementary Linear Algebra', '8', '$ 73', '4', '34'),
('987-013-0471109', 'ObjectOriented Software Engineering: Using UML', '2', '$ 63', '9', '10'),
('987-013-0661029', 'Computer Networks', '4', '$ 65', '12', '11'),
('987-013-0897923', 'Business Correspondence: A Guide to Everday Writing', '2', '$ 79', '20', '30'),
('987-013-1139480', 'Introductory Mathematical Analysis for business', '11', '$ 85', '60', '70'),
('987-013-1856059', 'Foundation of Finance', '6', '$ 82', '50', '11'),
('987-013-1856448', 'Computer Organization &amp; Architecure Designing for Performance', '7', '$ 56', '4', '16'),
('987-013-1869004', 'Visual Basic 2005 how to program', '3', '$ 90', '13', '16'),
('987-013-1976290', 'Objects First with JAVA a Practical Introduction Unsing Blue J', '3', '$ 51', '14', '12'),
('987-013-1989245', 'Digital Design', '4', '$ 52', '15', '11'),
('987-013-1991095', 'The Legal Enviroment of business and Online Commerce', '5', '$ 86', '4', '10'),
('987-013-2240857', 'System Analysis and Design', '7', '$ 94', '7', '9'),
('987-013-2277815', 'Essentials of Business Information Systems', '7', '$ 93', '20', '35'),
('987-013-2439602', 'Accounting', '7', '$ 75', '15', '16'),
('987-013-6006633', 'Modern Operating Systems', '3', '$ 67', '12', '12'),
('987-013-6007104', 'Fundamentals of Management', '6', '$ 87', '21', '18'),
('987-013-6014874', 'Operations Management', '9', '$ 88', '21', '15'),
('987-013-7903955', 'Artificial Intelligence: A modren Approach', '2', '$ 59', '21', '22'),
('987-019-4309240', 'Effective Academic Writing 3: The Essay', '2', '$ 102', '22', '23'),
('987-019-4372114', 'Sociolinguistics (Oxford Introductions to Linguistics)', '1998', '$ 104', '22', '55'),
('987-019-4372138', 'Psycholinguistics (Oxford Introductions to Language)', '1998', '$ 103', '10', '11'),
('987-026-2032933', 'Introduction to Algorithms', '2', '$ 57', '20', '9'),
('987-032-1210265', 'Software Engineering', '8', '$ 61', '9', '10'),
('987-032-1369574', 'Fundamentals of Database Systems', '5', '$ 64', '1', '17'),
('987-032-1409911', ' Problem Solving and Program design in C', '5', '$ 50', '4', '5'),
('987-032-1493620', 'Concepts of Programming Languages', '8', '$ 60', '1', '9'),
('987-041-5227636', 'Psychology and Education', '2002', '$ 95', '9', '9'),
('987-047-1472445', 'Calculus: Early Transcendentals Single and Multivariable', '8', '$ 72', '20', '40'),
('987-047-1715368', 'Data Management: Database &amp; Organizations', '5', '$ 92', '14', '13'),
('987-047-1738848', 'Data Structures and Algorithms in Java', '4', '$ 91', '33', '22'),
('987-052-1276429', 'Course Design: Developing Program and Materuals for Language Learning', '2', '$ 96', '22', '14'),
('987-052-143200', 'The Study of Language', '3', '$ 105', '33', '44'),
('987-052-1685436', 'Professional English in Use ICT Student''s Book', '1', '$ 68', '12', '13'),
('987-052-1702997', 'Infotech Student''s Book: English for Computer Users', '4', '$ 69', '19', '17'),
('987-053-4407582', 'Applied Calculus for the Managerial', '6', '$ 84', '3', '6'),
('987-053-4956004', 'Software Metrices', '2', '$ 62', '7', '9'),
('987-058-2838093', 'Market LeaderIntermediate Course Book', '2005', '$ 80', '6', '9'),
('987-140-5847186', 'Economics', '1', '$ 76', '11', '22'),
('987-185-2335779', 'Requirements Engineering', '1', '$ 66', '15', '12');

-- --------------------------------------------------------

--
-- بنية الجدول `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `code` varchar(10) NOT NULL,
  `book_ISBN` varchar(100) default NULL,
  PRIMARY KEY  (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- إرجاع أو إستيراد بيانات الجدول `courses`
--

INSERT INTO `courses` (`code`, `book_ISBN`) VALUES
('ACCT101', '987-013-2439602'),
('ACCT202', '987-013-2439602'),
('CS101', '987-032-1409911'),
('CS102', '987-013-1976290'),
('CS201', '987-013-1989245'),
('CS202', '987-007-3229720'),
('CS203', '987-013-2240857'),
('CS204', '987-047-1738848'),
('CS301', '987-013-1856448'),
('CS302', '987-026-2032933'),
('CS310', '987-032-1369574'),
('CS330', '987-013-7903955'),
('CS360', '987-032-1493620'),
('CS370', '987-032-1210265'),
('CS371', '987-053-4956004'),
('CS372', '987-013-0471109'),
('CS411', '987-032-1369574'),
('CS460', '987-013-0661029'),
('CS473', '987-185-2335779'),
('CS480', '987-013-6006633'),
('ECON101', '987-140-5847186'),
('EDU301', '987-041-5227636'),
('EDU402', '987-052-1276429'),
('ENGL101', '0-201-75571-8'),
('ENGL102', '0-201-75571-8'),
('ENGL111', '0-201-75570-X'),
('ENGL112', '0-201-75570-X'),
('ENGL115', '0-521-54496-3'),
('ENGL116', '987-019-4309240'),
('ENGL123', '0-201-75573-4'),
('ENGL124', '0-201-75573-4'),
('ENGL201', '987-052-1685436'),
('ENGL202', '987-052-1702997'),
('ENGL211', '987-013-0897923'),
('ENGL212', '987-058-2838093'),
('ENGL300', '987-007-1488488'),
('FIN330', '987-013-1856059'),
('LING302', '987-019-4372138'),
('LING303', '987-019-4372114'),
('LING304', '987-052-143200'),
('MAG301', '987-013-6007104'),
('MATH101', '987-047-1472445'),
('MATH102', '987-047-1472445'),
('MATH111', '987-053-4407582'),
('MATH112', '987-053-4407582'),
('MATH201', '987-047-1472445'),
('MATH202', '987-013-0457875'),
('MATH203', '987-013-1139480'),
('MGT201', '987-013-1991095'),
('MGT302', '987-013-6014874'),
('MIS101', '987-013-1869004'),
('MIS201', '987-047-1738848'),
('MIS202', '987-047-1715368'),
('MIS203', '987-013-2277815'),
('MIS341', '987-013-2240857'),
('MOS102', '987-013-1869004'),
('CS4XX', '987-013-6014874'),
('CS2XX', '987-013-2277815');

-- --------------------------------------------------------

--
-- بنية الجدول `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `m_id` varchar(100) NOT NULL,
  `m_type` varchar(100) NOT NULL,
  `name` varchar(299) default NULL,
  `gender` varchar(50) default NULL,
  `dep` varchar(100) default NULL,
  `status` varchar(50) default NULL,
  PRIMARY KEY  (`m_id`,`m_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- إرجاع أو إستيراد بيانات الجدول `member`
--

INSERT INTO `member` (`m_id`, `m_type`, `name`, `gender`, `dep`, `status`) VALUES
('08110210', 'student', 'Hassan abdurhman alshhri', 'male', 'CS', '0'),
('08110212', 'student', 'Hosam abdurhman alkabary', 'male', 'CS', '0'),
('08110211', 'student', 'khled mohammed', 'male', 'MIS', '0'),
('06110003', 'student', 'Ahmad Salim Awadh al-Juhani', 'male', 'CS', '0'),
('06110015', 'student', 'Ahmed Salim Salman Alalloni', 'male', 'CS', '0'),
('06110007', 'student', 'Ibrahim Ahmed Hamed Omari', 'male', 'MIS', '0'),
('06110019', 'student', 'Omar Hassan Omar Fallata', 'male', 'MIS', '0'),
('06110031', 'student', 'Mohammad Ahmad Mohammad Al-Zahrani', 'male', 'CS', '0'),
('07110005', 'student', 'Mohammed Saleh Al-Otaibi', 'male', 'CS', '0'),
('05110073', 'student', 'Abdurhman khaled halabi', 'male', 'CS', '0'),
('07210269', 'student', 'Yasser Mohammed Musleh Radadi', 'male', 'CS', '0'),
('07210328', 'student', 'Marwan Al-Hamid Sulaiman Al Subhi', 'male', 'LA', '0'),
('08210236', 'student', 'Fahad S. Al-Rashid Balawi', 'male', 'MIS', '0'),
('08210238', 'student', 'Abdulla Khalid Mohammed al-Harbi', 'male', 'MIS', '0'),
('08210250', 'student', 'Amer Ibrahim Mohammad Niaz', 'male', 'MIS', '0'),
('08210324', 'student', 'Adel Ahmed al-Maliki ', 'male', 'MIS', '0'),
('08210318', 'student', 'Tarek Ahmed Said Kaki', 'male', 'MIS', '0'),
('07110012', 'student', 'Hamza Mahmoud Hamza Abu al-Kheir', 'male', 'LA', '0'),
('07110018', 'student', 'Sami Mohamed Hussein Aburbeaih', 'male', 'LA', '0'),
('07110039', 'student', 'Ahmed Abdel Rahman Ahmed Sabri', 'male', 'LA', '0'),
('06120060', 'student', 'Amal Mohamed Selim Al Subhi', 'female', 'LA', '0'),
('06120045', 'student', ' Abrar Ali al-Ghamdi', 'female', 'LA', '0'),
('06120003', 'student', 'eman Abdallah  Balawi', 'female', 'CS', '0'),
('06120025', 'student', 'Halima Ahmed Hussein Shabelle', 'female', 'CS', '0'),
('08120034', 'student', 'Hanen Sami Hamid Almoagmsi', 'female', 'CS', '0'),
('07120006', 'student', 'Doaa Hussein Ali al-Hazmi', 'female', 'CS', '0'),
('07120012', 'student', 'Raghad Mohamed Attia al-Juhani', 'female', 'CS', '0'),
('07120018', 'student', 'Rnad Anwar Eid Al Rifai', 'female', 'CS', '0'),
('07120125', 'student', 'Zeinab Hamad Jaber Alvahmi', 'female', 'CS', '0'),
('08120113', 'student', 'Rawan Ali Salem Almatrafi', 'female', 'MIS', '0'),
('08120116', 'student', 'Sarah Mohammed Salman Balawi', 'female', 'MIS', '0'),
('08120135', 'student', 'Salwa Mohamed Ngemc ', 'female', 'MIS', '0'),
('08220027', 'student', 'Aisha Mohamed Hamed Faydi', 'female', 'MIS', '0'),
('06120110', 'student', 'Samar Mohamed Shehata Yanbaawi', 'female', 'LA', '0'),
('06120006', 'student', 'Abeer Salem Hamad Al-Amri', 'female', 'LA', '0'),
('07220029', 'student', 'Fatima Hamza Mohammad Yamani', 'female', 'LA', '0'),
('07220038', 'student', 'Manal Ali Subhi ', 'female', 'CS', '0'),
('07220040', 'student', 'Nora Saeed Hassan Menhali', 'female', 'CS', '0'),
('07120041', 'student', 'Wafa Razin Abdullah al-Sheikh', 'female', 'CS', '0'),
('07120038', 'student', 'Hadeel Qasim Abdullah Sindhi', 'female', 'CS', '0'),
('07120033', 'student', 'Hoda Mohamed Salah Al-Zeer', 'female', 'CS', '0'),
('50101', 'teacher', 'mohammed ahmed', 'male', 'CS', '0'),
('50102', 'teacher', 'abo baker mohammed', 'male', 'MIS', '0'),
('50106', 'teacher', 'jlal hassan', 'male', 'ENGL', '0'),
('50103', 'teacher', 'fatema ahmad', 'female', 'GS', '0'),
('50104', 'teacher', 'nora abdulaah', 'female', 'CS', '0'),
('50105', 'other', 'ahmad khaled', 'male', 'IT', '0');

-- --------------------------------------------------------

--
-- بنية الجدول `r_c`
--

CREATE TABLE IF NOT EXISTS `r_c` (
  `m_id` varchar(9) NOT NULL,
  `m_type` varchar(100) NOT NULL,
  `c_code` varchar(100) NOT NULL,
  `ISBN` varchar(100) default NULL,
  `deliver` int(9) default '0',
  `semester` varchar(100) NOT NULL,
  `user` varchar(100) default NULL,
  PRIMARY KEY  (`m_id`,`m_type`,`c_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- إرجاع أو إستيراد بيانات الجدول `r_c`
--

INSERT INTO `r_c` (`m_id`, `m_type`, `c_code`, `ISBN`, `deliver`, `semester`, `user`) VALUES
('06110003', 'student', 'CS201', '', 0, '82', NULL),
('06110015', 'student', 'CS201', NULL, 0, '82', NULL),
('06110007', 'student', 'ACCT101', '', 0, '82', NULL),
('06110019', 'student', 'ACCT101', NULL, 0, '82', NULL),
('06110003', 'student', 'CS202', '', 0, '82', NULL),
('06110015', 'student', 'CS202', NULL, 0, '82', NULL),
('06110007', 'student', 'ECON101', '', 0, '82', NULL),
('06110019', 'student', 'ECON101', NULL, 0, '82', NULL),
('06110003', 'student', 'CS203', '', 0, '91', '1'),
('06110015', 'student', 'CS203', '', 0, '91', '1'),
('06110007', 'student', 'MIS201', '', 0, '91', '1'),
('06110019', 'student', 'MIS201', '', 0, '91', NULL),
('06110003', 'student', 'CS204', '', 0, '91', '1'),
('06110015', 'student', 'CS204', '', 0, '91', '1'),
('06110007', 'student', 'MIS202', '', 0, '91', '1'),
('06110019', 'student', 'MIS202', '', 0, '91', NULL),
('08110210', 'student', 'CS204', '', 0, '82', '8'),
('08110210', 'student', 'CS203', '', 0, '82', '8'),
('08110210', 'student', 'MATH201', '', 0, '82', '8'),
('08110210', 'student', 'MATH202', '987-013-0457875', 2, '91', '1'),
('08110210', 'student', 'CS301', '987-013-1856448', 1, '91', '1'),
('08110210', 'student', 'CS310', '', 0, '91', '1'),
('08110210', 'student', 'CS370', '987-032-1210265', 2, '91', '1'),
('08110210', 'student', 'CS360', '', 0, '91', '1'),
('05110073', 'student', 'CS360', '987-032-1493620', 1, '91', '1'),
('05110073', 'student', 'CS203', '', 0, '82', NULL),
('05110073', 'student', 'CS204', '', 0, '82', NULL),
('05110073', 'student', 'MATH202', '', 2, '82', '1'),
('05110073', 'student', 'CS301', '', 0, '91', NULL),
('05110073', 'student', 'CS310', '987-032-1369574', 1, '91', '1'),
('05110073', 'student', 'CS370', '987-032-1210265', 1, '91', '1');

-- --------------------------------------------------------

--
-- بنية الجدول `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) default NULL,
  `email` varchar(100) default NULL,
  `password` varchar(150) default NULL,
  `mobile` varchar(50) default NULL,
  `group` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- إرجاع أو إستيراد بيانات الجدول `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `mobile`, `group`) VALUES
(1, 'Hassan alshhri', 'admin@admin.com', 'd9b1d7db4cd6e70935368a1efb10e377', '0553377622', 0),
(7, 'morad', 'morad@bis.com', 'd9b1d7db4cd6e70935368a1efb10e377', '0544395992', 1),
(8, 'test', 'test@bis.com', '09316f2857d5facffab6288e9ec873f4', '12345', 1);
